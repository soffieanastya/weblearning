
<div class="container" style="margin-top: 130px">
  <div class="row">
    <div class="col-lg-7 mx-auto">
    	<form action="<?php echo site_url('posttest/aksi_posttest'); ?>" method="post">		
			<h3 style="text-align: center;">POST TEST</h3><br>
			
      <P>
        1. Satuan dari beda potensial adalah <input type="text" name="jawaban1" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required>
      </P>
      <P>
        2.  Satuan dari resistansi adalah <input type="text" name="jawaban2" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required>
      </P>
      <P>
        3.  Perhatikan gambar berikut. <br>
        <img src="<?php echo base_url('assets/img/komponen/res1.PNG') ?>"><br>
        &nbsp;&nbsp;&nbsp;&nbsp;Gambar tersebut merupakan simbol dari <input type="text" name="jawaban3" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required>
      </P>
      <p>
        4.  Perhatikan gambar berikut.<br>
        <img src="<?php echo base_url('assets/img/komponen/res1.PNG') ?>"><br>
        &nbsp;&nbsp;&nbsp;&nbsp;Simbol komponen elektronika tersebut berfungsi sebagai <input type="text" name="jawaban4" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required> jumlah arus dalam rangkaian elektronika
      </p>
      <p>
        5.  Perhatikan gambar berikut.<br>
        <img src="<?php echo base_url('assets/img/komponen/kap.png') ?>"><br>
        &nbsp;&nbsp;&nbsp;&nbsp;Simbol komponen elektronika tersebut berfungsi untuk <input type="text" name="jawaban5" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required> muatan listrik selama waktu tertentu
      </p>
      <p>
        6.  Perhatikan gambar berikut.<br>
        <img src="<?php echo base_url('assets/img/komponen/induktor.png') ?>"><br> 
        Gambar tersebut merupakan simbol <input type="text" name="jawaban6" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required>
      </p>
      <p>
        7.  Perhatikan simbol rangkaian elektronika berikut <br>
        <img src="<?php echo base_url('assets/img/komponen/pnp.PNG') ?>"><br> 
        Simbol tersebut merupakan simbol dari rangkaian elektronika <input type="text" name="jawaban7" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required>
      </p>
      <p>
        8.  Kapasitor memiliki perbedaan dengan accu, yaitu terletak pada prosesnya. <input type="text" name="jawaban8" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required> tidak mengubahnya menjadi energi kimia.
      </p>
      <p>
        9.  Berikut ditunjukkan resistor.<br>
        <img src="<?php echo base_url('assets/img/posttest/1.PNG') ?>"><br> 
        dari gambar tersebut dapat kita simpulkan bahwa resistor 1 memiliki besar resistansi yang lebih <input type="text" name="jawaban9" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required> daripada resistor 2.
      </p>
      <p>
        10. Berikut ditunjukkan resistor.<br>
        <img src="<?php echo base_url('assets/img/posttest/2.PNG') ?>"><br>
        berdasarkan gambar tersebut, dapat disimpulkan bahwa resistor tersebut memiliki besar resistansi <input type="text" name="jawaban10" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required>
      </p>
      <p>
        11. Berikut ditunjukkan resistor.<br>
        <img src="<?php echo base_url('assets/img/posttest/3.PNG') ?>"><br>
        dari gambar tersebut dapat kita simpulkan bahwa resistor 1 memiliki besar toleransi yang lebih <input type="text" name="jawaban11" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required> daripada resistor 2.
      </p>
      <p>
        12. Berdasarkan hukum <input type="text" name="jawaban12" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required>, kuat arus listrik yang mengalir berbanding lurus dengan tegangan dan berbanding terbalik dengan hambatannya.
      </p>
      <p>
        13. Berdasarkan hukum ohm, beda potensial berbanding <input type="text" name="jawaban13" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required> dengan arus listrik
      </p>
      <p>
        14. Sebuah resistor 110 Ω dihubungkan dengan baterai. Kuat arus yang mengalir adalah 30 mA. Beda potensial dari baterai tersebut adalah <input type="text" name="jawaban14" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required> Volt
      </p>
      <p>
        15. Besar dari 0,5 F = <input type="text" name="jawaban15" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required> µF
      </p>
      <p>
        16. Besar dari 30 dF = <input type="text" name="jawaban16" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required> F
      </p>
      <p>
        17. Perhatikan gambar berikut.<br>
        <img src="<?php echo base_url('assets/img/posttest/4.PNG') ?>"><br> 
        Jika C1  = 2 µF, dan C2  = 4 µF, 
        maka kapasitas kapasitor penggantinya adalah <input type="text" name="jawaban17" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required> µF
      </p>
      <p>
        18. Sebuah resistor 120 Ω dihubungkan dengan baterai. Kuat arus yang mengalir adalah 0,25 A. Beda potensial dari baterai tersebut adalah <input type="text" name="jawaban18" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required> volt
      </p>
      <p>
        19. Perhatikan gambar berikut.<br>
        <img src="<?php echo base_url('assets/img/posttest/5.PNG') ?>"><br>  
        Diketahui bahwa R1 = 3 Ω, R2 = 12 Ω, R3 = 2 Ω, dan tegangan sumber V = 20 v. maka besar hambatan pengganti (Rtotal) nya adalah <input type="text" name="jawaban19" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required> ohm
      </p>
      <p>
        20. Perhatikan gambar berikut<br>
        <img src="<?php echo base_url('assets/img/posttest/6.PNG') ?>"><br>  
        Diketahui bahwa R1 = 6; R2 = 7; R3 = 2. Besar hambatan pengganti (R¬T) adalah <input type="text" name="jawaban20" placeholder="&nbsp;&nbsp;&nbsp;jawaban" required> ohm
      </p>

      <br>

      <div>
        <input type="submit" value="NEXT" type="button" class="btn btn-info" style="width: 100%"> 
      </div>

    	</form>
    </div>
  </div>
</div>