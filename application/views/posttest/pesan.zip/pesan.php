
<div class="container" style="margin-top: 200px">
  <div class="row text-center">
    <div class="col-lg-7 mx-auto">
    	<h1>Selamat!</h1>
      <h4>kamu telah menyelesaikan POST TEST!</h4>
      <img src="<?php echo base_url('assets/congrats.gif') ?>">
    </div>
  </div>
</div>