<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Posttest extends CI_Controller {

	public function __construct(){
		parent::__construct();

		$this->load->model('model_siskom');
		$this->load->helper('url_helper');
	}

	public function no1(){
		$title['judul'] = 'Soal Rangkaian Elektronika';
		$this->load->view('headernfooter/header', $title);

		#cari cara buat ngembaliin nilai dari view ke controller, terus pilih yg mananya
		$this->load->view('posttest/no1');
		$this->load->view('headernfooter/footer');
	}

	public function aksi_posttest(){
		$title['judul'] = 'Soal Rangkaian Elektronika';
		$this->load->view('headernfooter/header', $title);

		$cekjawaban = $this->input->post('jawaban1');
		if($cekjawaban == "tinggi"){
			redirect ('soal/no2');
		}else{
			$this->load->view('latihan1/no1');
			$this->load->view('latihan1/salah');
		}
		
		$this->load->view('headernfooter/footer');
	}


}

?>